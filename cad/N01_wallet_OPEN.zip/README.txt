NOIR ATELIER N°01 — complete wallet (lid OPEN)
One STEP solid for review / volume.
Outer ~92.0 x 60.4 mm · R1.8
Hinge method still open — please advise best approach.
Web: https://www.noir-atelier.com/cnc/
